
public class main {

	public static void main(String[] args) {
		Menu m1 = new Menu();
		m1.displayMainMenu();
	}

}
