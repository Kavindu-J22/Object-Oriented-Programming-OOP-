package user;

/**
 * This class refers to methods and data relating to the Manager.
 * @author blazing squad
 */
public class Manager extends StaffUser {
	
	/**
	 * @param clientid, eventid and cost to offer discount to event
	 * @return the new cost for event
	 */
	public int offerDiscount(int clientid, int eventid, int cost) {
		int newcost=0;
		return newcost;
	}
}
